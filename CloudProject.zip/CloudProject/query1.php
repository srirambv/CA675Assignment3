<!DOCTYPE html>

<?php

/* Open connection to MySQL database. */
$mysqli = new mysqli("localhost", "root", "qcNBcNeqW3", "Test");
 
/* Check the connection. */
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}

?>

<html>
  <head>

<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript" src="http://cdn.zingchart.com/zingchart.min.js"></script>
<script type="text/javascript">


<?php
$data=mysqli_query($mysqli,"SELECT * FROM Revisions");
?>


var myData=[<?php 
while($info=mysqli_fetch_array($data))
    echo $info['Revisions'].','; /* We use the concatenation operator '.' to add comma delimiters after each data value. */
?>];
        
<?php
$data=mysqli_query($mysqli,"SELECT * FROM Revisions");
?>
        
var myLabels=[<?php 
while($info=mysqli_fetch_array($data))
    echo '"'.$info['Year'].'",'; /* The concatenation operator '.' is used here to create string values from our database names. */
?>];

window.onload=function(){  // Render Method[2]
    zingchart.render({ 
      id:'myChart',
      height:400,
      width:600,
      data:{
    "type":"bar",
    "title":{
        "text":"Wiki Data on Yearly Revisions"
    },
    "scale-x":{
        "labels":myLabels
    },
    "series":[
        {
            "values":myData
        }
]
}
});
};

</script>


</head>
<body>
<?php
include 'header.php';
?>
<!--Chart Placement[3]-->
<div id ='myChart'></div>
</body>
</html>