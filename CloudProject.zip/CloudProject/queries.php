<?php
include 'header.php';
?>

<html>
    <head>
        <link rel="stylesheet" href="main.css" type="text/css">
        <title>Contact</title>
    </head>

    <body>
        
        <div class="query_buttons"> <a href="query1.php" class="button">How many revisions were done each year?</a> </div>
        <div class="query_buttons"> <a href="query2.php" class="button">Which pages got revised most often?</a> </div>
        <div class="query_buttons"> <a href="query3.php" class="button">Which posts have the most anonymous edits?</a> </div>
        <div class="query_buttons"> <a href="query4.php" class="button">Who are the top editors?</a> </div>
        
    </body>
</html>