<?php
include 'header.php';
?>

<!DOCTYPE html>
<html>
  <head>

<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript" src="http://cdn.zingchart.com/zingchart.min.js"></script>
<script> zingchart.MODULESDIR = "https://cdn.zingchart.com/modules/";
		ZC.LICENSE = ["569d52cefae586f634c54f86dc99e6a9","ee6b7db5b51705a13dc2339db3edaf6d"];</script>
<script type="text/javascript">

var myConfig = {
  "type":"pie",
  "plot":{
    "value-box":{
      "visible":true,
      "placement":"out",
      "text":"Nr revisions: %v <br> Title: %t"
    }
  },
  "series": [
    {
      "values":[59546],
      "text":"The history of Cuba"
    },
    {
      "values":[3455],
      "text":"Albert Einstein"
    },
    {
      "values":[22909],
      "text":"Pomegranates"
    },
    {
      "values":[2556],
      "text":"Simone de Beauvoir"
    },
    {
      "values":[9097],
      "text":"Greenpeace"
    }
  ]
};
 
window.onload=function(){
zingchart.render({ 
	id : 'myChart2', 
	data : myConfig, 
	height: "100%", 
	width: "100%" 
});
};
</script>
<body>
    <div id='myChart2'></div>
</body>
</html>

