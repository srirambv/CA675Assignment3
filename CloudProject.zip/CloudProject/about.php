
<?php
include 'header.php';
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>About</title>
        <link rel="stylesheet" href="main.css" type="text/css"/>
    </head>
    <body>

        <div class="aboutcontact">
        
	    <h1 style="font-size:250%">About Us</h1>
		
            <p> Do you want to find out which changes have been made to the Wikipedia entries in the last 6 years? </p>
            <p> Well, look no further! </p>
            <p> On this website you can browse through a variety of queries that give you some interesting information about all
                Wikipedia entry revisions since August 2009. </p>
            <p> The data set used has the following pieces of information for each revision entry: </p>
            
            <p> <i> <b>Page ID, Title of the Page, Revision ID, Revision Time Stamp, Contributor IP (if edit is anonymous) <br>
                        Contributor Username, Contributor User ID, Comment (comment of revision), Text (of the revision) </b></i> </p>
            <p> For now, we only provide a couple of pre-processed queries to get you started. But a fully interactively
                query system is soon to come! </p>
            <p> If you would like to suggest queries, feel free to contact us! </p>

		
	</div>
        
    </body>
</html>