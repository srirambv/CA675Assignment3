<!DOCTYPE html>

<html>
    <body>
      
        
        <a href="index.php">
        <div id="header">
            <h1>  WIKIPEDIA EDITS </h1>
        </div>
        </a>
        
        <table align="center" id="navtable">
            <tr>
                <td id="navbutton"> Browse all Wikipedia meta data of all pages created since 2009</td>
            </tr>
        </table>
    </body>
</html>


