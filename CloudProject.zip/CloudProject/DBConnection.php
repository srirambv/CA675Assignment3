<?php
      
    $ServerName = "localhost";
    $DatabaseName = "Test";
    $UserName = "root";
    $Password = "qcNBcNeqW3";
    
    //Step 1- 
    
    $ServerConnnectionStatus =  mysql_connect($ServerName, $UserName, $Password);
    
    if($ServerConnnectionStatus)
        echo"<br> Connection to the Server Succesful@ $ServerName";
    else
        echo"<br> Connection to the Server Unsuccesful@ $ServerName";  
    
    //Step 2 - 
    
     $DatabaseConnnectionStatus =  mysql_select_db($DatabaseName);
     if($DatabaseConnnectionStatus)
        echo"<br> Connection to the Database Succesful@ $DatabaseName";
     else
        echo"<br> Connection to the Server Unsuccesful@ $DatabaseName"; 

