<!DOCTYPE html>

<?php

include 'header.php';

?>

<html>
  <head>

<link rel="stylesheet" href="main.css" type="text/css" />

  </head>
  <body>
      
      <div id="names">
      <p> 1. Dalai Lama  :                     410 Edits </p>
      <p> 2. Rolf Kreier  :                    309 Edits </p>
      <p> 3. lala909       :                   308 Edits </p>
      <p> 4. Sita Naham     :                  300 Edits </p>
      <p> 5. Krausi         :                  291 Edits</p>
                                
      </div>
      <div id="names2">
      <p> 6. Mufasa         :                  290 Edits</p>
      <p> 7. 90295           :                222 Edits </p>
      <p> 8. Mike Dunn        :                209 Edits </p>
      <p> 9. Special Sarah     :               108 Edits </p>
      <p> 10. Pri92            :               100 Edits <p>
      </div>
      
  </body>
</html>