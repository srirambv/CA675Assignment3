<?php
include 'header.php';
?>

<html>
    <head>
         <meta charset="UTF-8">
         <link rel="stylesheet" href="main.css" type="text/css">
         <title> WIKIPEDIA EDITS </title>
    </head>
    <body>
       
       
       <div id = "about_ball">
        
           <a href="about.php">
               <img id="about" src="about.png" width="140%" height="140%"/> 
           </a>
           
       </div>
       <div id="queries_ball">
           <a href="queries.php">
               <img id="queries" src="queries.png" width="60%" height="60%"/> 
           </a>
           
        </div>
        
        <div id ="contact_ball">
            <a href="contact.php">
               <img id="queries" src="contact.png" width="20%" height="20%"/> 
           </a>
        </div>
    </body>
</html>



   



