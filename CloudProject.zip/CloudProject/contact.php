<?php
include 'header.php';
?>

<!DOCTYPE html>

<html>
    <head>
        <link rel="stylesheet" href="main.css" type="text/css">
        <title>Contact</title>
    </head>

    <body>


        <div class="aboutcontact">
            <div>
                <h1 style="font-size:300%">Contact Us</h1>

                <h2>Send us a message</h2>


                <form action="" method="POST">
                    First name:
                    <input type="text" name="firstname" value=""> <br>
                    <br>
                    Last name:
                    <input type="text" name="lastname" value=""> <br>
                    <br>
                    </div>

                    <div class="topicinput">
                        Topic:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp     
                        <input type="text" name="topic" value=""> <br>
                        <br>
                    </div>

                    <div>
                        Question:&nbsp;
                        <input type="text" name="question" value="">
                        <br>
                        <br>
                        <input type="submit" value="Submit">
                        
                    </div>
                    </form>
            </div>

    </body>
</html>

