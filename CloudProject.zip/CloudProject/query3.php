<?php
include 'header.php';
?>

<!DOCTYPE html>
<html>
  <head>

<link rel="stylesheet" href="main.css" type="text/css" />
<script type="text/javascript" src="http://cdn.zingchart.com/zingchart.min.js"></script>
<script> zingchart.MODULESDIR = "https://cdn.zingchart.com/modules/";
		ZC.LICENSE = ["569d52cefae586f634c54f86dc99e6a9","ee6b7db5b51705a13dc2339db3edaf6d"];</script>
<script type="text/javascript">

var myConfig = {
  "type":"pie",
  "tooltip":{
    "visible":true,
    "text":"Nr anonymous revisions: %v <br> Title: %t "
  },
  "series": [
    {
      "values":[5559],
      "text":"Avocados"
    },
    {
      "values":[5522],
      "text":"Drew Barrymore"
    },
    {
      "values":[3504],
      "text":"Science Fiction"
    },
    {
      "values":[2528],
      "text":"Game of Thrones"
    },
    {
      "values":[851],
      "text":"Da Vinci"
    }
  ]
};
 
window.onload=function(){
zingchart.render({ 
	id : 'myChart3', 
	data : myConfig, 
	height: "100%", 
	width: "100%" 
});
};
</script>
<body>
    <div id='myChart3'></div>
</body>
</html>

